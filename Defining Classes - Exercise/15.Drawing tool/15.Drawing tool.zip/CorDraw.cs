﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15.Drawing_tool
{
    public class CorDraw
    {
        public static void DrawFigure(Rectangle rectangl)
        {
            Console.WriteLine(rectangl.ToString());
        }
    }
}
