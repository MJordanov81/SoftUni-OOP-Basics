﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.Mordor_s_Cruelty_Plan
{
    public class Lembas : Food
    {
        public override int Happiness
        {
            get { return 3; }
        }
    }
}
