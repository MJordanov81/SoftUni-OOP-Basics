﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Team
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private List<Person> firstTeam;

        public IList<Person> FirstTeam
        {
            get { return firstTeam.AsReadOnly(); }
            set { firstTeam = value.ToList(); }
        }

        private List<Person> reserveTeam;

        public IList<Person> ReserveTeam
        {
            get { return reserveTeam.AsReadOnly(); }
            set { reserveTeam = value.ToList(); }
        }

        public Team(string name)
        {
            this.Name = name;
            this.FirstTeam = new List<Person>();
            this.ReserveTeam = new List<Person>();
        }

        public void AddPlayer(Person player)
        {
            if (player.Age < 40)
            {
                firstTeam.Add(player);
            }
            else
            {
                reserveTeam.Add(player);
            }
        }
    }

