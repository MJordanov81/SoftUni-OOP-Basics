﻿
using System;
using System.Linq;

public class StartUp
{
    public static void Main()
    {
        Engine.RunEngine();
    }
}

