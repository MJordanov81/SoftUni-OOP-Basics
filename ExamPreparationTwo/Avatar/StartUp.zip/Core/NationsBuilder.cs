﻿using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;

public class NationsBuilder
{
/*    private Nation airNation;
    private Nation waterNation;
    private Nation fireNation;
    private Nation earthNation;*/
    private Dictionary<string, Nation> nations;
    private List<string> warsList;
    private int warsCount;

    public NationsBuilder()
    {
/*        this.airNation = new Nation("Air");
        this.waterNation = new Nation("Water");
        this.fireNation = new Nation("Fire");
        this.earthNation = new Nation("Earth");*/
        this.nations = new Dictionary<string, Nation>()
        {
            {"Air", new Nation("Air")},
            {"Water", new Nation("Water")},
            {"Fire", new Nation("Fire")},
            {"Earth", new Nation("Earth")}
        };
        this.warsList = new List<string>();
        this.warsCount = 1;
    }

    public void AssignBender(List<string> benderArgs)
    {
        var type = benderArgs[0];
        var name = benderArgs[1];
        var power = int.Parse(benderArgs[2]);
        var secondaryParameter = double.Parse(benderArgs[3]);

        var bender = BenderFactory.MakeBender(type, name, power, secondaryParameter);

        /*        switch (type)
                {
                    case "Air":
                        this.airNation.Benders.Add(bender);
                        break;

                    case "Water":
                        this.waterNation.Benders.Add(bender);
                        break;

                    case "Fire":
                        this.fireNation.Benders.Add(bender);
                        break;

                    case "Earth":
                        this.earthNation.Benders.Add(bender);
                        break;
                }*/

        this.nations[type].Benders.Add(bender);
    }

    public void AssignMonument(List<string> monumentArgs)
    {
        var type = monumentArgs[0];
        var name = monumentArgs[1];
        var affinity = int.Parse(monumentArgs[2]);

        var monument = MonumentFactory.MakeMonument(type, name, affinity);

/*        switch (type)
        {
            case "Air":
                this.airNation.Monuments.Add(monument);
                break;

            case "Water":
                this.waterNation.Monuments.Add(monument);
                break;

            case "Fire":
                this.fireNation.Monuments.Add(monument);
                break;

            case "Earth":
                this.earthNation.Monuments.Add(monument);
                break;
        }*/

        this.nations[type].Monuments.Add(monument);
    }

    public string GetStatus(string nationsType)
    {
/*        switch (nationsType)
        {
            case "Air":
                return airNation.ToString(nationsType);

            case "Water":
                return waterNation.ToString(nationsType);

            case "Fire":
                return fireNation.ToString(nationsType);

            default:
                return earthNation.ToString(nationsType);
        }*/

        return this.nations[nationsType].ToString(nationsType);
    }

    public void IssueWar(string nationsType)
    {
/*        var nationsList = new List<Nation>
        {
            this.airNation,
            this.waterNation,
            this.fireNation,
            this.earthNation
        };*/

        Battle battle = new Battle(this.nations);

        var winner = battle.GetWinnerType();

        foreach (var nation in this.nations)
        {
            if (nation.Key != winner)
            {
                nation.Value.Benders.Clear();
                nation.Value.Monuments.Clear();
            }
        }

        this.warsList.Add($"War {warsCount} issued by {nationsType}");
        warsCount++;
    }

    public string GetWarsRecord()
    {
        StringBuilder sb = new StringBuilder();

        if (this.warsList.Count > 0)
        {
            foreach (var war in this.warsList)
            {
                sb.AppendLine(war);
            }
        }

        return sb.ToString().Trim();
    }
}

