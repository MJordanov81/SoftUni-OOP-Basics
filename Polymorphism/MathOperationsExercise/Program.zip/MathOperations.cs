﻿public class MathOperations
{
    public int Add(int integerOne, int IntegerTwo)
    {
        return integerOne + IntegerTwo;
    }

    public double Add(double doubleOne, double doubleTwo, double doubleThree)
    {
        return doubleOne + doubleTwo + doubleThree;
    }

    public decimal Add(decimal decimalOne, decimal decimalTwo, decimal decimalThree)
    {
        return decimalOne + decimalTwo + decimalThree;
    }
}
